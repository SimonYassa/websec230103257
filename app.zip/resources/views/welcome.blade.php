@extends('layouts.master')
@section('title', 'Welcome')
@section('content')
    <div class="card m-4">
      <div class="card-body">
        Welcome to Home Page
      </div>
    </div>
@endsection
