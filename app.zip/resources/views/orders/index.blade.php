@extends('layouts.master')

@section('content')
<h2>Your Orders</h2>
<table class="table">
    <tr>
        <th>Product</th>
        <th>Price</th>
        <th>Date</th>
    </tr>
    @foreach($orders as $order)
    <tr>
        <td>{{ $order->product->name }}</td>
        <td>${{ $order->total_price }}</td>
        <td>{{ $order->created_at }}</td>
    </tr>
    @endforeach
</table>
@endsection
