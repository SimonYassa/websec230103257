@extends('layouts.master')

@section('content')
<div class="container">
    <!-- Simple Welcome Section -->
    <div class="row my-5">
        <div class="col-12 text-center">
            <h1 class="display-4">Welcome to WebSecTest Store</h1>
            <p class="lead mb-4">Your one-stop shop for quality products</p>
        </div>
    </div>
</div>
@endsection
