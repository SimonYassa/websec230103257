<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ProfileController extends Controller
{
    // Display user profile page
    public function index()
    {
        return view('profile.index'); // Make sure you have a "profile/index.blade.php" view
    }

    // Update user profile
    public function update(Request $request)
    {
        // Example validation (modify as needed)
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email,' . auth()->id(),
        ]);

        // Update the user profile
        auth()->user()->update($request->only(['name', 'email']));

        return redirect()->back()->with('success', 'Profile updated successfully.');
    }
}
