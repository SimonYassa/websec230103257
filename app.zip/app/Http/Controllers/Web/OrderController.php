<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Order;
use App\Models\Product;
use App\Models\User;
use Illuminate\Support\Facades\Auth;

class OrderController extends Controller
{
    /**
     * Display a list of the authenticated user's orders.
     */
    public function index()
    {
        $orders = Auth::user()->orders()->with('product')->get();
        return view('orders.index', compact('orders'));
    }

    /**
     * Show a specific order details.
     */
    public function show(Order $order)
    {
        if ($order->user_id !== Auth::id()) {
            return redirect()->route('orders.index')->with('error', 'Unauthorized access.');
        }
        return view('orders.show', compact('order'));
    }

    /**
     * Purchase a product.
     */
    public function purchase(Request $request, $productId)
    {
        $product = Product::findOrFail($productId);
        $user = Auth::user();

        $request->validate([
            'quantity' => 'required|integer|min:1'
        ]);

        $quantity = $request->input('quantity');
        $totalPrice = $product->price * $quantity;

        // Check if user has enough credit and if the product is in stock
        if ($user->credit < $totalPrice) {
            return redirect()->back()->with('error', 'Insufficient credit.');
        }

        if ($product->stock < $quantity) {
            return redirect()->back()->with('error', 'Not enough stock available.');
        }

        // Deduct stock and user credit
        $product->stock -= $quantity;
        $product->save();

        $user->credit -= $totalPrice;
        $user->save();

        // Create the order
        Order::create([
            'user_id' => $user->id,
            'product_id' => $product->id,
            'quantity' => $quantity,
            'total_price' => $totalPrice,
        ]);

        return redirect()->route('orders.index')->with('success', 'Purchase successful.');
    }

    /**
     * List all orders (for admin use).
     */
    public function listAllOrders()
    {
        if (Auth::user()->role !== 'admin') {
            return redirect()->route('orders.index')->with('error', 'Unauthorized access.');
        }

        $orders = Order::with(['user', 'product'])->get();
        return view('orders.admin-index', compact('orders'));
    }
}
